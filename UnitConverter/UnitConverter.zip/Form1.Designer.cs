﻿
namespace UnitConverter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.arrow1 = new System.Windows.Forms.PictureBox();
            this.lbLen1 = new System.Windows.Forms.Label();
            this.unitLen2 = new System.Windows.Forms.Label();
            this.unitLen1 = new System.Windows.Forms.Label();
            this.lbLen2 = new System.Windows.Forms.Label();
            this.toBox = new System.Windows.Forms.ListBox();
            this.LengthConvertButton = new System.Windows.Forms.Button();
            this.fromText = new System.Windows.Forms.TextBox();
            this.toText = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.fromBox = new System.Windows.Forms.ListBox();
            this.Units = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.arrow2 = new System.Windows.Forms.PictureBox();
            this.lb21 = new System.Windows.Forms.Label();
            this.lb24 = new System.Windows.Forms.Label();
            this.lb22 = new System.Windows.Forms.Label();
            this.lb23 = new System.Windows.Forms.Label();
            this.WeightConverButton = new System.Windows.Forms.Button();
            this.fromTextWeight = new System.Windows.Forms.TextBox();
            this.toTextWeight = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.toBoxWeight = new System.Windows.Forms.ListBox();
            this.label5 = new System.Windows.Forms.Label();
            this.fromBoxWeight = new System.Windows.Forms.ListBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.arrow3 = new System.Windows.Forms.PictureBox();
            this.lb31 = new System.Windows.Forms.Label();
            this.lb34 = new System.Windows.Forms.Label();
            this.lb32 = new System.Windows.Forms.Label();
            this.lb33 = new System.Windows.Forms.Label();
            this.TempConverButton = new System.Windows.Forms.Button();
            this.fromTextTemp = new System.Windows.Forms.TextBox();
            this.toTextTemp = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.toBoxTemp = new System.Windows.Forms.ListBox();
            this.label6 = new System.Windows.Forms.Label();
            this.fromBoxTemp = new System.Windows.Forms.ListBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.arrow4 = new System.Windows.Forms.PictureBox();
            this.lb41 = new System.Windows.Forms.Label();
            this.lb44 = new System.Windows.Forms.Label();
            this.lb42 = new System.Windows.Forms.Label();
            this.lb43 = new System.Windows.Forms.Label();
            this.AngleConvertButton = new System.Windows.Forms.Button();
            this.fromTextAngle = new System.Windows.Forms.TextBox();
            this.toTextAngle = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.toBoxAngle = new System.Windows.Forms.ListBox();
            this.label8 = new System.Windows.Forms.Label();
            this.fromBoxAngle = new System.Windows.Forms.ListBox();
            this.Volume = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.arrow5 = new System.Windows.Forms.PictureBox();
            this.lb51 = new System.Windows.Forms.Label();
            this.lb54 = new System.Windows.Forms.Label();
            this.lb52 = new System.Windows.Forms.Label();
            this.lb53 = new System.Windows.Forms.Label();
            this.VolumeConvertButton = new System.Windows.Forms.Button();
            this.fromTextVol = new System.Windows.Forms.TextBox();
            this.toTextVol = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.toBoxVol = new System.Windows.Forms.ListBox();
            this.label10 = new System.Windows.Forms.Label();
            this.fromBoxVol = new System.Windows.Forms.ListBox();
            this.Length = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.arrow6 = new System.Windows.Forms.PictureBox();
            this.lb61 = new System.Windows.Forms.Label();
            this.lb64 = new System.Windows.Forms.Label();
            this.lb62 = new System.Windows.Forms.Label();
            this.lb63 = new System.Windows.Forms.Label();
            this.PressureConvertButton = new System.Windows.Forms.Button();
            this.fromTextPressure = new System.Windows.Forms.TextBox();
            this.toTextPressure = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.toBoxPressure = new System.Windows.Forms.ListBox();
            this.label12 = new System.Windows.Forms.Label();
            this.fromBoxPressure = new System.Windows.Forms.ListBox();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.arrow7 = new System.Windows.Forms.PictureBox();
            this.lb71 = new System.Windows.Forms.Label();
            this.lb74 = new System.Windows.Forms.Label();
            this.lb72 = new System.Windows.Forms.Label();
            this.lb73 = new System.Windows.Forms.Label();
            this.ForceConvertButton = new System.Windows.Forms.Button();
            this.fromTextForce = new System.Windows.Forms.TextBox();
            this.toTextForce = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.toBoxForce = new System.Windows.Forms.ListBox();
            this.label14 = new System.Windows.Forms.Label();
            this.fromBoxForce = new System.Windows.Forms.ListBox();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.arrow8 = new System.Windows.Forms.PictureBox();
            this.lb81 = new System.Windows.Forms.Label();
            this.lb84 = new System.Windows.Forms.Label();
            this.lb82 = new System.Windows.Forms.Label();
            this.lb83 = new System.Windows.Forms.Label();
            this.EnergyConvertButton = new System.Windows.Forms.Button();
            this.fromTextEnergy = new System.Windows.Forms.TextBox();
            this.toTextEnergy = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.toBoxEnergy = new System.Windows.Forms.ListBox();
            this.label16 = new System.Windows.Forms.Label();
            this.fromBoxEnergy = new System.Windows.Forms.ListBox();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.arrow9 = new System.Windows.Forms.PictureBox();
            this.lb91 = new System.Windows.Forms.Label();
            this.lb94 = new System.Windows.Forms.Label();
            this.lb92 = new System.Windows.Forms.Label();
            this.lb93 = new System.Windows.Forms.Label();
            this.SpeedConvertButton = new System.Windows.Forms.Button();
            this.fromTextSpeed = new System.Windows.Forms.TextBox();
            this.toTextSpeed = new System.Windows.Forms.TextBox();
            this.from = new System.Windows.Forms.Label();
            this.toBoxSpeed = new System.Windows.Forms.ListBox();
            this.label18 = new System.Windows.Forms.Label();
            this.fromBoxSpeed = new System.Windows.Forms.ListBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.arrow1)).BeginInit();
            this.Units.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.arrow2)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.arrow3)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.arrow4)).BeginInit();
            this.Volume.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.arrow5)).BeginInit();
            this.Length.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.arrow6)).BeginInit();
            this.tabPage6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.arrow7)).BeginInit();
            this.tabPage7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8)).BeginInit();
            this.tabPage8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9)).BeginInit();
            this.SuspendLayout();
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.toBox);
            this.tabPage1.Controls.Add(this.LengthConvertButton);
            this.tabPage1.Controls.Add(this.fromText);
            this.tabPage1.Controls.Add(this.toText);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.fromBox);
            this.tabPage1.Location = new System.Drawing.Point(104, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(584, 400);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Length";
            this.tabPage1.Paint += new System.Windows.Forms.PaintEventHandler(this.tabPage1_Paint);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.arrow1);
            this.groupBox1.Controls.Add(this.lbLen1);
            this.groupBox1.Controls.Add(this.unitLen2);
            this.groupBox1.Controls.Add(this.unitLen1);
            this.groupBox1.Controls.Add(this.lbLen2);
            this.groupBox1.Location = new System.Drawing.Point(341, 39);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(170, 170);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            // 
            // arrow1
            // 
            this.arrow1.Image = ((System.Drawing.Image)(resources.GetObject("arrow1.Image")));
            this.arrow1.Location = new System.Drawing.Point(66, 64);
            this.arrow1.Name = "arrow1";
            this.arrow1.Size = new System.Drawing.Size(40, 40);
            this.arrow1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.arrow1.TabIndex = 12;
            this.arrow1.TabStop = false;
            this.arrow1.Visible = false;
            // 
            // lbLen1
            // 
            this.lbLen1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lbLen1.Location = new System.Drawing.Point(15, 18);
            this.lbLen1.Name = "lbLen1";
            this.lbLen1.Size = new System.Drawing.Size(140, 20);
            this.lbLen1.TabIndex = 8;
            this.lbLen1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // unitLen2
            // 
            this.unitLen2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.unitLen2.Location = new System.Drawing.Point(15, 136);
            this.unitLen2.Name = "unitLen2";
            this.unitLen2.Size = new System.Drawing.Size(140, 20);
            this.unitLen2.TabIndex = 11;
            this.unitLen2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // unitLen1
            // 
            this.unitLen1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.unitLen1.Location = new System.Drawing.Point(15, 35);
            this.unitLen1.Name = "unitLen1";
            this.unitLen1.Size = new System.Drawing.Size(140, 20);
            this.unitLen1.TabIndex = 9;
            this.unitLen1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbLen2
            // 
            this.lbLen2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lbLen2.Location = new System.Drawing.Point(2, 116);
            this.lbLen2.Name = "lbLen2";
            this.lbLen2.Size = new System.Drawing.Size(166, 20);
            this.lbLen2.TabIndex = 10;
            this.lbLen2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // toBox
            // 
            this.toBox.FormattingEnabled = true;
            this.toBox.IntegralHeight = false;
            this.toBox.Items.AddRange(new object[] {
            "Meter                                      [m]",
            "Milimeter                              [mm]",
            "Centimeter                            [cm]",
            "Inch                                      [in\"]",
            "Foot                                      [Ft\']",
            "Kilometer                              [km]",
            "Nanometer                           [nm]",
            "Micrometer                           [μm]",
            "Mile                                      [mi.]",
            "Yard                                      [yd]",
            "Light Year                               [ly]"});
            this.toBox.Location = new System.Drawing.Point(175, 45);
            this.toBox.Name = "toBox";
            this.toBox.Size = new System.Drawing.Size(160, 238);
            this.toBox.TabIndex = 5;
            // 
            // LengthConvertButton
            // 
            this.LengthConvertButton.Location = new System.Drawing.Point(175, 19);
            this.LengthConvertButton.Name = "LengthConvertButton";
            this.LengthConvertButton.Size = new System.Drawing.Size(160, 20);
            this.LengthConvertButton.TabIndex = 7;
            this.LengthConvertButton.Text = "Convert";
            this.LengthConvertButton.UseVisualStyleBackColor = true;
            this.LengthConvertButton.Click += new System.EventHandler(this.convertButton_Click);
            // 
            // fromText
            // 
            this.fromText.Location = new System.Drawing.Point(9, 19);
            this.fromText.Name = "fromText";
            this.fromText.Size = new System.Drawing.Size(160, 20);
            this.fromText.TabIndex = 2;
            this.fromText.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fromText_KeyDown);
            this.fromText.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.fromText_KeyPress);
            // 
            // toText
            // 
            this.toText.Location = new System.Drawing.Point(341, 19);
            this.toText.Name = "toText";
            this.toText.ReadOnly = true;
            this.toText.Size = new System.Drawing.Size(170, 20);
            this.toText.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "From:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(341, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Result:";
            // 
            // fromBox
            // 
            this.fromBox.FormattingEnabled = true;
            this.fromBox.Items.AddRange(new object[] {
            "Meter                                      [m]",
            "Milimeter                              [mm]",
            "Centimeter                            [cm]",
            "Inch                                      [in\"]",
            "Foot                                      [Ft\']",
            "Kilometer                              [km]",
            "Nanometer                           [nm]",
            "Micrometer                           [μm]",
            "Mile                                      [mi.]",
            "Yard                                      [yd]",
            "Light Year                               [ly]"});
            this.fromBox.Location = new System.Drawing.Point(9, 45);
            this.fromBox.Name = "fromBox";
            this.fromBox.Size = new System.Drawing.Size(160, 238);
            this.fromBox.TabIndex = 4;
            // 
            // Units
            // 
            this.Units.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.Units.Controls.Add(this.tabPage1);
            this.Units.Controls.Add(this.tabPage2);
            this.Units.Controls.Add(this.tabPage3);
            this.Units.Controls.Add(this.tabPage4);
            this.Units.Controls.Add(this.Volume);
            this.Units.Controls.Add(this.Length);
            this.Units.Controls.Add(this.tabPage6);
            this.Units.Controls.Add(this.tabPage7);
            this.Units.Controls.Add(this.tabPage8);
            this.Units.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.Units.ItemSize = new System.Drawing.Size(25, 100);
            this.Units.Location = new System.Drawing.Point(12, 12);
            this.Units.Multiline = true;
            this.Units.Name = "Units";
            this.Units.SelectedIndex = 0;
            this.Units.Size = new System.Drawing.Size(692, 408);
            this.Units.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.Units.TabIndex = 8;
            this.Units.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.Units_DrawItem);
            this.Units.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Units_MouseClick);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.WeightConverButton);
            this.tabPage2.Controls.Add(this.fromTextWeight);
            this.tabPage2.Controls.Add(this.toTextWeight);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.toBoxWeight);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.fromBoxWeight);
            this.tabPage2.Location = new System.Drawing.Point(104, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(584, 400);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Weight";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.arrow2);
            this.groupBox2.Controls.Add(this.lb21);
            this.groupBox2.Controls.Add(this.lb24);
            this.groupBox2.Controls.Add(this.lb22);
            this.groupBox2.Controls.Add(this.lb23);
            this.groupBox2.Location = new System.Drawing.Point(341, 39);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(170, 170);
            this.groupBox2.TabIndex = 14;
            this.groupBox2.TabStop = false;
            // 
            // arrow2
            // 
            this.arrow2.Image = ((System.Drawing.Image)(resources.GetObject("arrow2.Image")));
            this.arrow2.Location = new System.Drawing.Point(66, 64);
            this.arrow2.Name = "arrow2";
            this.arrow2.Size = new System.Drawing.Size(40, 40);
            this.arrow2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.arrow2.TabIndex = 12;
            this.arrow2.TabStop = false;
            this.arrow2.Visible = false;
            // 
            // lb21
            // 
            this.lb21.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lb21.Location = new System.Drawing.Point(15, 18);
            this.lb21.Name = "lb21";
            this.lb21.Size = new System.Drawing.Size(140, 20);
            this.lb21.TabIndex = 8;
            this.lb21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb24
            // 
            this.lb24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb24.Location = new System.Drawing.Point(2, 139);
            this.lb24.Name = "lb24";
            this.lb24.Size = new System.Drawing.Size(166, 20);
            this.lb24.TabIndex = 11;
            this.lb24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb22
            // 
            this.lb22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb22.Location = new System.Drawing.Point(15, 35);
            this.lb22.Name = "lb22";
            this.lb22.Size = new System.Drawing.Size(140, 20);
            this.lb22.TabIndex = 9;
            this.lb22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb23
            // 
            this.lb23.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lb23.Location = new System.Drawing.Point(2, 116);
            this.lb23.Name = "lb23";
            this.lb23.Size = new System.Drawing.Size(166, 20);
            this.lb23.TabIndex = 10;
            this.lb23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // WeightConverButton
            // 
            this.WeightConverButton.Location = new System.Drawing.Point(175, 19);
            this.WeightConverButton.Name = "WeightConverButton";
            this.WeightConverButton.Size = new System.Drawing.Size(160, 20);
            this.WeightConverButton.TabIndex = 4;
            this.WeightConverButton.Text = "Convert";
            this.WeightConverButton.UseVisualStyleBackColor = true;
            this.WeightConverButton.Click += new System.EventHandler(this.WeightConverButton_Click);
            // 
            // fromTextWeight
            // 
            this.fromTextWeight.Location = new System.Drawing.Point(9, 19);
            this.fromTextWeight.Name = "fromTextWeight";
            this.fromTextWeight.Size = new System.Drawing.Size(160, 20);
            this.fromTextWeight.TabIndex = 3;
            this.fromTextWeight.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fromTextWeight_KeyDown);
            this.fromTextWeight.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.fromTextWeight_KeyPress);
            // 
            // toTextWeight
            // 
            this.toTextWeight.Location = new System.Drawing.Point(341, 19);
            this.toTextWeight.Name = "toTextWeight";
            this.toTextWeight.ReadOnly = true;
            this.toTextWeight.Size = new System.Drawing.Size(170, 20);
            this.toTextWeight.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "From:";
            // 
            // toBoxWeight
            // 
            this.toBoxWeight.FormattingEnabled = true;
            this.toBoxWeight.Items.AddRange(new object[] {
            "Kilogram                                [kg]",
            "Ton                                          [t]",
            "Gram                                       [g]",
            "Miligram                                [mg]",
            "Pound                                   [lbs]",
            "Ounce                                   [oz]",
            "Carat                               [car, ct]"});
            this.toBoxWeight.Location = new System.Drawing.Point(175, 45);
            this.toBoxWeight.Name = "toBoxWeight";
            this.toBoxWeight.Size = new System.Drawing.Size(160, 238);
            this.toBoxWeight.TabIndex = 13;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(341, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Result:";
            // 
            // fromBoxWeight
            // 
            this.fromBoxWeight.FormattingEnabled = true;
            this.fromBoxWeight.Items.AddRange(new object[] {
            "Kilogram                                [kg]",
            "Ton                                          [t]",
            "Gram                                       [g]",
            "Miligram                                [mg]",
            "Pound                                   [lbs]",
            "Ounce                                   [oz]",
            "Carat                               [car, ct]"});
            this.fromBoxWeight.Location = new System.Drawing.Point(9, 45);
            this.fromBoxWeight.Name = "fromBoxWeight";
            this.fromBoxWeight.Size = new System.Drawing.Size(160, 238);
            this.fromBoxWeight.TabIndex = 12;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage3.Controls.Add(this.groupBox3);
            this.tabPage3.Controls.Add(this.TempConverButton);
            this.tabPage3.Controls.Add(this.fromTextTemp);
            this.tabPage3.Controls.Add(this.toTextTemp);
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Controls.Add(this.toBoxTemp);
            this.tabPage3.Controls.Add(this.label6);
            this.tabPage3.Controls.Add(this.fromBoxTemp);
            this.tabPage3.Location = new System.Drawing.Point(104, 4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(584, 400);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Temperature";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.arrow3);
            this.groupBox3.Controls.Add(this.lb31);
            this.groupBox3.Controls.Add(this.lb34);
            this.groupBox3.Controls.Add(this.lb32);
            this.groupBox3.Controls.Add(this.lb33);
            this.groupBox3.Location = new System.Drawing.Point(341, 39);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(170, 170);
            this.groupBox3.TabIndex = 22;
            this.groupBox3.TabStop = false;
            // 
            // arrow3
            // 
            this.arrow3.Image = ((System.Drawing.Image)(resources.GetObject("arrow3.Image")));
            this.arrow3.Location = new System.Drawing.Point(66, 64);
            this.arrow3.Name = "arrow3";
            this.arrow3.Size = new System.Drawing.Size(40, 40);
            this.arrow3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.arrow3.TabIndex = 12;
            this.arrow3.TabStop = false;
            this.arrow3.Visible = false;
            // 
            // lb31
            // 
            this.lb31.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lb31.Location = new System.Drawing.Point(15, 18);
            this.lb31.Name = "lb31";
            this.lb31.Size = new System.Drawing.Size(140, 20);
            this.lb31.TabIndex = 8;
            this.lb31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb34
            // 
            this.lb34.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb34.Location = new System.Drawing.Point(15, 136);
            this.lb34.Name = "lb34";
            this.lb34.Size = new System.Drawing.Size(140, 20);
            this.lb34.TabIndex = 11;
            this.lb34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb32
            // 
            this.lb32.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb32.Location = new System.Drawing.Point(15, 35);
            this.lb32.Name = "lb32";
            this.lb32.Size = new System.Drawing.Size(140, 20);
            this.lb32.TabIndex = 9;
            this.lb32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb33
            // 
            this.lb33.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lb33.Location = new System.Drawing.Point(2, 116);
            this.lb33.Name = "lb33";
            this.lb33.Size = new System.Drawing.Size(166, 20);
            this.lb33.TabIndex = 10;
            this.lb33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TempConverButton
            // 
            this.TempConverButton.Location = new System.Drawing.Point(175, 19);
            this.TempConverButton.Name = "TempConverButton";
            this.TempConverButton.Size = new System.Drawing.Size(160, 20);
            this.TempConverButton.TabIndex = 6;
            this.TempConverButton.Text = "Convert";
            this.TempConverButton.UseVisualStyleBackColor = true;
            this.TempConverButton.Click += new System.EventHandler(this.TempConverButton_Click);
            // 
            // fromTextTemp
            // 
            this.fromTextTemp.Location = new System.Drawing.Point(9, 19);
            this.fromTextTemp.Name = "fromTextTemp";
            this.fromTextTemp.Size = new System.Drawing.Size(160, 20);
            this.fromTextTemp.TabIndex = 5;
            this.fromTextTemp.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fromTextTemp_KeyDown);
            this.fromTextTemp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.fromTextTemp_KeyPress);
            // 
            // toTextTemp
            // 
            this.toTextTemp.Location = new System.Drawing.Point(341, 19);
            this.toTextTemp.Name = "toTextTemp";
            this.toTextTemp.ReadOnly = true;
            this.toTextTemp.Size = new System.Drawing.Size(170, 20);
            this.toTextTemp.TabIndex = 19;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 13);
            this.label3.TabIndex = 16;
            this.label3.Text = "From:";
            // 
            // toBoxTemp
            // 
            this.toBoxTemp.FormattingEnabled = true;
            this.toBoxTemp.Items.AddRange(new object[] {
            "Kelvin                                     [K]",
            "Celsius                                   [°C]",
            "Fahrenheit                             [°F]",
            "Rankine                                [°R]",
            "Reaumur                                 [°r]"});
            this.toBoxTemp.Location = new System.Drawing.Point(175, 45);
            this.toBoxTemp.Name = "toBoxTemp";
            this.toBoxTemp.Size = new System.Drawing.Size(160, 238);
            this.toBoxTemp.TabIndex = 21;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(341, 3);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 13);
            this.label6.TabIndex = 17;
            this.label6.Text = "Result:";
            // 
            // fromBoxTemp
            // 
            this.fromBoxTemp.FormattingEnabled = true;
            this.fromBoxTemp.Items.AddRange(new object[] {
            "Kelvin                                     [K]",
            "Celsius                                   [°C]",
            "Fahrenheit                             [°F]",
            "Rankine                                [°R]",
            "Reaumur                                 [°r]"});
            this.fromBoxTemp.Location = new System.Drawing.Point(9, 45);
            this.fromBoxTemp.Name = "fromBoxTemp";
            this.fromBoxTemp.Size = new System.Drawing.Size(160, 238);
            this.fromBoxTemp.TabIndex = 20;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage4.Controls.Add(this.groupBox4);
            this.tabPage4.Controls.Add(this.AngleConvertButton);
            this.tabPage4.Controls.Add(this.fromTextAngle);
            this.tabPage4.Controls.Add(this.toTextAngle);
            this.tabPage4.Controls.Add(this.label7);
            this.tabPage4.Controls.Add(this.toBoxAngle);
            this.tabPage4.Controls.Add(this.label8);
            this.tabPage4.Controls.Add(this.fromBoxAngle);
            this.tabPage4.Location = new System.Drawing.Point(104, 4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(584, 400);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Angle";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.arrow4);
            this.groupBox4.Controls.Add(this.lb41);
            this.groupBox4.Controls.Add(this.lb44);
            this.groupBox4.Controls.Add(this.lb42);
            this.groupBox4.Controls.Add(this.lb43);
            this.groupBox4.Location = new System.Drawing.Point(341, 39);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(170, 170);
            this.groupBox4.TabIndex = 29;
            this.groupBox4.TabStop = false;
            // 
            // arrow4
            // 
            this.arrow4.Image = ((System.Drawing.Image)(resources.GetObject("arrow4.Image")));
            this.arrow4.Location = new System.Drawing.Point(66, 64);
            this.arrow4.Name = "arrow4";
            this.arrow4.Size = new System.Drawing.Size(40, 40);
            this.arrow4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.arrow4.TabIndex = 12;
            this.arrow4.TabStop = false;
            this.arrow4.Visible = false;
            // 
            // lb41
            // 
            this.lb41.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lb41.Location = new System.Drawing.Point(15, 18);
            this.lb41.Name = "lb41";
            this.lb41.Size = new System.Drawing.Size(140, 20);
            this.lb41.TabIndex = 8;
            this.lb41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb44
            // 
            this.lb44.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb44.Location = new System.Drawing.Point(15, 136);
            this.lb44.Name = "lb44";
            this.lb44.Size = new System.Drawing.Size(140, 20);
            this.lb44.TabIndex = 11;
            this.lb44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb42
            // 
            this.lb42.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb42.Location = new System.Drawing.Point(15, 35);
            this.lb42.Name = "lb42";
            this.lb42.Size = new System.Drawing.Size(140, 20);
            this.lb42.TabIndex = 9;
            this.lb42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb43
            // 
            this.lb43.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lb43.Location = new System.Drawing.Point(2, 116);
            this.lb43.Name = "lb43";
            this.lb43.Size = new System.Drawing.Size(166, 20);
            this.lb43.TabIndex = 10;
            this.lb43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // AngleConvertButton
            // 
            this.AngleConvertButton.Location = new System.Drawing.Point(175, 19);
            this.AngleConvertButton.Name = "AngleConvertButton";
            this.AngleConvertButton.Size = new System.Drawing.Size(160, 20);
            this.AngleConvertButton.TabIndex = 8;
            this.AngleConvertButton.Text = "Convert";
            this.AngleConvertButton.UseVisualStyleBackColor = true;
            this.AngleConvertButton.Click += new System.EventHandler(this.AngleConvertButton_Click);
            // 
            // fromTextAngle
            // 
            this.fromTextAngle.Location = new System.Drawing.Point(9, 19);
            this.fromTextAngle.Name = "fromTextAngle";
            this.fromTextAngle.Size = new System.Drawing.Size(160, 20);
            this.fromTextAngle.TabIndex = 7;
            this.fromTextAngle.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fromTextAngle_KeyDown);
            this.fromTextAngle.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.fromTextAngle_KeyPress);
            // 
            // toTextAngle
            // 
            this.toTextAngle.Location = new System.Drawing.Point(341, 19);
            this.toTextAngle.Name = "toTextAngle";
            this.toTextAngle.ReadOnly = true;
            this.toTextAngle.Size = new System.Drawing.Size(170, 20);
            this.toTextAngle.TabIndex = 26;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 3);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(33, 13);
            this.label7.TabIndex = 23;
            this.label7.Text = "From:";
            // 
            // toBoxAngle
            // 
            this.toBoxAngle.FormattingEnabled = true;
            this.toBoxAngle.Items.AddRange(new object[] {
            "Degree                                    [°]",
            "Radian                                 [rad]",
            "Grad                                      [^g]",
            "Minute                                      [\']",
            "Second                                    [\'\']"});
            this.toBoxAngle.Location = new System.Drawing.Point(175, 45);
            this.toBoxAngle.Name = "toBoxAngle";
            this.toBoxAngle.Size = new System.Drawing.Size(160, 238);
            this.toBoxAngle.TabIndex = 28;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(341, 3);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(40, 13);
            this.label8.TabIndex = 24;
            this.label8.Text = "Result:";
            // 
            // fromBoxAngle
            // 
            this.fromBoxAngle.FormattingEnabled = true;
            this.fromBoxAngle.Items.AddRange(new object[] {
            "Degree                                    [°]",
            "Radian                                 [rad]",
            "Grad                                      [^g]",
            "Minute                                      [\']",
            "Second                                    [\'\']"});
            this.fromBoxAngle.Location = new System.Drawing.Point(9, 45);
            this.fromBoxAngle.Name = "fromBoxAngle";
            this.fromBoxAngle.Size = new System.Drawing.Size(160, 238);
            this.fromBoxAngle.TabIndex = 27;
            // 
            // Volume
            // 
            this.Volume.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Volume.Controls.Add(this.groupBox5);
            this.Volume.Controls.Add(this.VolumeConvertButton);
            this.Volume.Controls.Add(this.fromTextVol);
            this.Volume.Controls.Add(this.toTextVol);
            this.Volume.Controls.Add(this.label9);
            this.Volume.Controls.Add(this.toBoxVol);
            this.Volume.Controls.Add(this.label10);
            this.Volume.Controls.Add(this.fromBoxVol);
            this.Volume.Location = new System.Drawing.Point(104, 4);
            this.Volume.Name = "Volume";
            this.Volume.Padding = new System.Windows.Forms.Padding(3);
            this.Volume.Size = new System.Drawing.Size(584, 400);
            this.Volume.TabIndex = 4;
            this.Volume.Text = "Volume";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.arrow5);
            this.groupBox5.Controls.Add(this.lb51);
            this.groupBox5.Controls.Add(this.lb54);
            this.groupBox5.Controls.Add(this.lb52);
            this.groupBox5.Controls.Add(this.lb53);
            this.groupBox5.Location = new System.Drawing.Point(341, 39);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(170, 170);
            this.groupBox5.TabIndex = 36;
            this.groupBox5.TabStop = false;
            // 
            // arrow5
            // 
            this.arrow5.Image = ((System.Drawing.Image)(resources.GetObject("arrow5.Image")));
            this.arrow5.Location = new System.Drawing.Point(66, 64);
            this.arrow5.Name = "arrow5";
            this.arrow5.Size = new System.Drawing.Size(40, 40);
            this.arrow5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.arrow5.TabIndex = 12;
            this.arrow5.TabStop = false;
            this.arrow5.Visible = false;
            // 
            // lb51
            // 
            this.lb51.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lb51.Location = new System.Drawing.Point(15, 18);
            this.lb51.Name = "lb51";
            this.lb51.Size = new System.Drawing.Size(140, 20);
            this.lb51.TabIndex = 8;
            this.lb51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb54
            // 
            this.lb54.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb54.Location = new System.Drawing.Point(15, 136);
            this.lb54.Name = "lb54";
            this.lb54.Size = new System.Drawing.Size(140, 20);
            this.lb54.TabIndex = 11;
            this.lb54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb52
            // 
            this.lb52.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb52.Location = new System.Drawing.Point(15, 35);
            this.lb52.Name = "lb52";
            this.lb52.Size = new System.Drawing.Size(140, 20);
            this.lb52.TabIndex = 9;
            this.lb52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb53
            // 
            this.lb53.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lb53.Location = new System.Drawing.Point(2, 116);
            this.lb53.Name = "lb53";
            this.lb53.Size = new System.Drawing.Size(166, 20);
            this.lb53.TabIndex = 10;
            this.lb53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // VolumeConvertButton
            // 
            this.VolumeConvertButton.Location = new System.Drawing.Point(175, 19);
            this.VolumeConvertButton.Name = "VolumeConvertButton";
            this.VolumeConvertButton.Size = new System.Drawing.Size(160, 20);
            this.VolumeConvertButton.TabIndex = 10;
            this.VolumeConvertButton.Text = "Convert";
            this.VolumeConvertButton.UseVisualStyleBackColor = true;
            this.VolumeConvertButton.Click += new System.EventHandler(this.VolumeConvertButton_Click);
            // 
            // fromTextVol
            // 
            this.fromTextVol.Location = new System.Drawing.Point(9, 19);
            this.fromTextVol.Name = "fromTextVol";
            this.fromTextVol.Size = new System.Drawing.Size(160, 20);
            this.fromTextVol.TabIndex = 9;
            this.fromTextVol.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fromTextVol_KeyDown);
            this.fromTextVol.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.fromTextVol_KeyPress);
            // 
            // toTextVol
            // 
            this.toTextVol.Location = new System.Drawing.Point(341, 19);
            this.toTextVol.Name = "toTextVol";
            this.toTextVol.ReadOnly = true;
            this.toTextVol.Size = new System.Drawing.Size(170, 20);
            this.toTextVol.TabIndex = 33;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 3);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(33, 13);
            this.label9.TabIndex = 30;
            this.label9.Text = "From:";
            // 
            // toBoxVol
            // 
            this.toBoxVol.FormattingEnabled = true;
            this.toBoxVol.Items.AddRange(new object[] {
            "Cubic meter                           [m³]",
            "Cubic centimeter                 [cm³]",
            "Cubic milimeter                    [mm³]",
            "Cubic decimeter                  [dm³]",
            "Liter                                       [L,l]",
            "Milliliter                                   [ml]",
            "Gallon                                   [gal]",
            "Quart                                      [qt]",
            "Pint                                        [pt]",
            "Cubic yard                            [yd³]",
            "Cubic foot                              [ft³]",
            "Cubic inch                             [in³]",
            "Cubic kilometer                    [km³]",
            "Cubic mile                             [mi³]"});
            this.toBoxVol.Location = new System.Drawing.Point(175, 45);
            this.toBoxVol.Name = "toBoxVol";
            this.toBoxVol.Size = new System.Drawing.Size(160, 238);
            this.toBoxVol.TabIndex = 35;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(341, 3);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(40, 13);
            this.label10.TabIndex = 31;
            this.label10.Text = "Result:";
            // 
            // fromBoxVol
            // 
            this.fromBoxVol.FormattingEnabled = true;
            this.fromBoxVol.Items.AddRange(new object[] {
            "Cubic meter                           [m³]",
            "Cubic centimeter                 [cm³]",
            "Cubic milimeter                    [mm³]",
            "Cubic decimeter                  [dm³]",
            "Liter                                       [L,l]",
            "Milliliter                                   [ml]",
            "Gallon                                   [gal]",
            "Quart                                      [qt]",
            "Pint                                        [pt]",
            "Cubic yard                            [yd³]",
            "Cubic foot                              [ft³]",
            "Cubic inch                             [in³]",
            "Cubic kilometer                    [km³]",
            "Cubic mile                             [mi³]"});
            this.fromBoxVol.Location = new System.Drawing.Point(9, 45);
            this.fromBoxVol.Name = "fromBoxVol";
            this.fromBoxVol.Size = new System.Drawing.Size(160, 238);
            this.fromBoxVol.TabIndex = 34;
            // 
            // Length
            // 
            this.Length.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Length.Controls.Add(this.groupBox6);
            this.Length.Controls.Add(this.PressureConvertButton);
            this.Length.Controls.Add(this.fromTextPressure);
            this.Length.Controls.Add(this.toTextPressure);
            this.Length.Controls.Add(this.label11);
            this.Length.Controls.Add(this.toBoxPressure);
            this.Length.Controls.Add(this.label12);
            this.Length.Controls.Add(this.fromBoxPressure);
            this.Length.Location = new System.Drawing.Point(104, 4);
            this.Length.Name = "Length";
            this.Length.Padding = new System.Windows.Forms.Padding(3);
            this.Length.Size = new System.Drawing.Size(584, 400);
            this.Length.TabIndex = 5;
            this.Length.Text = "Pressure";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.arrow6);
            this.groupBox6.Controls.Add(this.lb61);
            this.groupBox6.Controls.Add(this.lb64);
            this.groupBox6.Controls.Add(this.lb62);
            this.groupBox6.Controls.Add(this.lb63);
            this.groupBox6.Location = new System.Drawing.Point(341, 39);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(170, 170);
            this.groupBox6.TabIndex = 43;
            this.groupBox6.TabStop = false;
            // 
            // arrow6
            // 
            this.arrow6.Image = ((System.Drawing.Image)(resources.GetObject("arrow6.Image")));
            this.arrow6.Location = new System.Drawing.Point(66, 64);
            this.arrow6.Name = "arrow6";
            this.arrow6.Size = new System.Drawing.Size(40, 40);
            this.arrow6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.arrow6.TabIndex = 12;
            this.arrow6.TabStop = false;
            this.arrow6.Visible = false;
            // 
            // lb61
            // 
            this.lb61.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lb61.Location = new System.Drawing.Point(15, 18);
            this.lb61.Name = "lb61";
            this.lb61.Size = new System.Drawing.Size(140, 20);
            this.lb61.TabIndex = 8;
            this.lb61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb64
            // 
            this.lb64.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb64.Location = new System.Drawing.Point(-3, 136);
            this.lb64.Name = "lb64";
            this.lb64.Size = new System.Drawing.Size(155, 31);
            this.lb64.TabIndex = 11;
            this.lb64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb62
            // 
            this.lb62.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb62.Location = new System.Drawing.Point(15, 35);
            this.lb62.Name = "lb62";
            this.lb62.Size = new System.Drawing.Size(140, 20);
            this.lb62.TabIndex = 9;
            this.lb62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb63
            // 
            this.lb63.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lb63.Location = new System.Drawing.Point(2, 116);
            this.lb63.Name = "lb63";
            this.lb63.Size = new System.Drawing.Size(166, 20);
            this.lb63.TabIndex = 10;
            this.lb63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PressureConvertButton
            // 
            this.PressureConvertButton.Location = new System.Drawing.Point(175, 19);
            this.PressureConvertButton.Name = "PressureConvertButton";
            this.PressureConvertButton.Size = new System.Drawing.Size(160, 20);
            this.PressureConvertButton.TabIndex = 12;
            this.PressureConvertButton.Text = "Convert";
            this.PressureConvertButton.UseVisualStyleBackColor = true;
            this.PressureConvertButton.Click += new System.EventHandler(this.PressureConvertButton_Click);
            // 
            // fromTextPressure
            // 
            this.fromTextPressure.Location = new System.Drawing.Point(9, 19);
            this.fromTextPressure.Name = "fromTextPressure";
            this.fromTextPressure.Size = new System.Drawing.Size(160, 20);
            this.fromTextPressure.TabIndex = 11;
            this.fromTextPressure.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fromTextPressure_KeyDown);
            this.fromTextPressure.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.fromTextPressure_KeyPress);
            // 
            // toTextPressure
            // 
            this.toTextPressure.Location = new System.Drawing.Point(341, 19);
            this.toTextPressure.Name = "toTextPressure";
            this.toTextPressure.ReadOnly = true;
            this.toTextPressure.Size = new System.Drawing.Size(170, 20);
            this.toTextPressure.TabIndex = 40;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 3);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(33, 13);
            this.label11.TabIndex = 37;
            this.label11.Text = "From:";
            // 
            // toBoxPressure
            // 
            this.toBoxPressure.FormattingEnabled = true;
            this.toBoxPressure.Items.AddRange(new object[] {
            "Pascal\t                              [Pa]",
            "Kilopascal                           [kPa]",
            "bar\t                             [bar]",
            "atm\t                            [atm]",
            "Psi\t                              [psi]",
            "Ksi                                        [ksi]",
            "Gigapascal                         [GPa]",
            "Megapascal                       [MPa]",
            "Millipascal                          [mPa]",
            "Millibar                               [mbar]",
            "Newton/Square meter",
            "Newton/Square millimeter",
            "Kilogram-force/Square meter",
            "Kilogram-force/Square millimeter",
            "Pound-force/Square foot",
            "Pound-force/Square inch"});
            this.toBoxPressure.Location = new System.Drawing.Point(175, 45);
            this.toBoxPressure.Name = "toBoxPressure";
            this.toBoxPressure.Size = new System.Drawing.Size(160, 238);
            this.toBoxPressure.TabIndex = 42;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(341, 3);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(40, 13);
            this.label12.TabIndex = 38;
            this.label12.Text = "Result:";
            // 
            // fromBoxPressure
            // 
            this.fromBoxPressure.FormattingEnabled = true;
            this.fromBoxPressure.Items.AddRange(new object[] {
            "Pascal\t                              [Pa]",
            "Kilopascal                           [kPa]",
            "bar\t                             [bar]",
            "atm\t                            [atm]",
            "Psi\t                              [psi]",
            "Ksi                                        [ksi]",
            "Gigapascal                         [GPa]",
            "Megapascal                       [MPa]",
            "Millipascal                          [mPa]",
            "Millibar                               [mbar]",
            "Newton/Square meter",
            "Newton/Square millimeter",
            "Kilogram-force/Square meter",
            "Kilogram-force/Square millimeter",
            "Pound-force/Square foot",
            "Pound-force/Square inch"});
            this.fromBoxPressure.Location = new System.Drawing.Point(9, 45);
            this.fromBoxPressure.Name = "fromBoxPressure";
            this.fromBoxPressure.Size = new System.Drawing.Size(160, 238);
            this.fromBoxPressure.TabIndex = 41;
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage6.Controls.Add(this.groupBox7);
            this.tabPage6.Controls.Add(this.ForceConvertButton);
            this.tabPage6.Controls.Add(this.fromTextForce);
            this.tabPage6.Controls.Add(this.toTextForce);
            this.tabPage6.Controls.Add(this.label13);
            this.tabPage6.Controls.Add(this.toBoxForce);
            this.tabPage6.Controls.Add(this.label14);
            this.tabPage6.Controls.Add(this.fromBoxForce);
            this.tabPage6.Location = new System.Drawing.Point(104, 4);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(584, 400);
            this.tabPage6.TabIndex = 6;
            this.tabPage6.Text = "Force";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.arrow7);
            this.groupBox7.Controls.Add(this.lb71);
            this.groupBox7.Controls.Add(this.lb74);
            this.groupBox7.Controls.Add(this.lb72);
            this.groupBox7.Controls.Add(this.lb73);
            this.groupBox7.Location = new System.Drawing.Point(341, 39);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(170, 170);
            this.groupBox7.TabIndex = 50;
            this.groupBox7.TabStop = false;
            // 
            // arrow7
            // 
            this.arrow7.Image = ((System.Drawing.Image)(resources.GetObject("arrow7.Image")));
            this.arrow7.Location = new System.Drawing.Point(66, 64);
            this.arrow7.Name = "arrow7";
            this.arrow7.Size = new System.Drawing.Size(40, 40);
            this.arrow7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.arrow7.TabIndex = 12;
            this.arrow7.TabStop = false;
            this.arrow7.Visible = false;
            // 
            // lb71
            // 
            this.lb71.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lb71.Location = new System.Drawing.Point(15, 18);
            this.lb71.Name = "lb71";
            this.lb71.Size = new System.Drawing.Size(140, 20);
            this.lb71.TabIndex = 8;
            this.lb71.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb74
            // 
            this.lb74.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb74.Location = new System.Drawing.Point(15, 136);
            this.lb74.Name = "lb74";
            this.lb74.Size = new System.Drawing.Size(140, 20);
            this.lb74.TabIndex = 11;
            this.lb74.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb72
            // 
            this.lb72.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb72.Location = new System.Drawing.Point(15, 35);
            this.lb72.Name = "lb72";
            this.lb72.Size = new System.Drawing.Size(140, 20);
            this.lb72.TabIndex = 9;
            this.lb72.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb73
            // 
            this.lb73.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lb73.Location = new System.Drawing.Point(2, 116);
            this.lb73.Name = "lb73";
            this.lb73.Size = new System.Drawing.Size(166, 20);
            this.lb73.TabIndex = 10;
            this.lb73.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ForceConvertButton
            // 
            this.ForceConvertButton.Location = new System.Drawing.Point(175, 19);
            this.ForceConvertButton.Name = "ForceConvertButton";
            this.ForceConvertButton.Size = new System.Drawing.Size(160, 20);
            this.ForceConvertButton.TabIndex = 14;
            this.ForceConvertButton.Text = "Convert";
            this.ForceConvertButton.UseVisualStyleBackColor = true;
            this.ForceConvertButton.Click += new System.EventHandler(this.ForceConvertButton_Click);
            // 
            // fromTextForce
            // 
            this.fromTextForce.Location = new System.Drawing.Point(9, 19);
            this.fromTextForce.Name = "fromTextForce";
            this.fromTextForce.Size = new System.Drawing.Size(160, 20);
            this.fromTextForce.TabIndex = 13;
            this.fromTextForce.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fromTextForce_KeyDown);
            this.fromTextForce.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.fromTextForce_KeyPress);
            // 
            // toTextForce
            // 
            this.toTextForce.Location = new System.Drawing.Point(341, 19);
            this.toTextForce.Name = "toTextForce";
            this.toTextForce.ReadOnly = true;
            this.toTextForce.Size = new System.Drawing.Size(170, 20);
            this.toTextForce.TabIndex = 47;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 3);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(33, 13);
            this.label13.TabIndex = 44;
            this.label13.Text = "From:";
            // 
            // toBoxForce
            // 
            this.toBoxForce.FormattingEnabled = true;
            this.toBoxForce.Items.AddRange(new object[] {
            "Newton                                  [N]",
            "Kilonewton                           [kN]",
            "Kilogram-force                      [kgf]",
            "Dekanewton                      [daN]",
            "Gram-force                             [gf]",
            "Ton-force                                [tf]",
            "Giganewton                         [GN]",
            "Meganewton                       [MN]",
            "Joule/meter                         [J/m]"});
            this.toBoxForce.Location = new System.Drawing.Point(175, 45);
            this.toBoxForce.Name = "toBoxForce";
            this.toBoxForce.Size = new System.Drawing.Size(160, 238);
            this.toBoxForce.TabIndex = 49;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(341, 3);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(40, 13);
            this.label14.TabIndex = 45;
            this.label14.Text = "Result:";
            // 
            // fromBoxForce
            // 
            this.fromBoxForce.FormattingEnabled = true;
            this.fromBoxForce.Items.AddRange(new object[] {
            "Newton                                  [N]",
            "Kilonewton                           [kN]",
            "Kilogram-force                      [kgf]",
            "Dekanewton                      [daN]",
            "Gram-force                             [gf]",
            "Ton-force                                [tf]",
            "Giganewton                         [GN]",
            "Meganewton                       [MN]",
            "Joule/meter                         [J/m]"});
            this.fromBoxForce.Location = new System.Drawing.Point(9, 45);
            this.fromBoxForce.Name = "fromBoxForce";
            this.fromBoxForce.Size = new System.Drawing.Size(160, 238);
            this.fromBoxForce.TabIndex = 48;
            // 
            // tabPage7
            // 
            this.tabPage7.BackColor = System.Drawing.Color.Transparent;
            this.tabPage7.Controls.Add(this.groupBox8);
            this.tabPage7.Controls.Add(this.EnergyConvertButton);
            this.tabPage7.Controls.Add(this.fromTextEnergy);
            this.tabPage7.Controls.Add(this.toTextEnergy);
            this.tabPage7.Controls.Add(this.label15);
            this.tabPage7.Controls.Add(this.toBoxEnergy);
            this.tabPage7.Controls.Add(this.label16);
            this.tabPage7.Controls.Add(this.fromBoxEnergy);
            this.tabPage7.Location = new System.Drawing.Point(104, 4);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(584, 400);
            this.tabPage7.TabIndex = 7;
            this.tabPage7.Text = "Energy";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.arrow8);
            this.groupBox8.Controls.Add(this.lb81);
            this.groupBox8.Controls.Add(this.lb84);
            this.groupBox8.Controls.Add(this.lb82);
            this.groupBox8.Controls.Add(this.lb83);
            this.groupBox8.Location = new System.Drawing.Point(341, 39);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(170, 170);
            this.groupBox8.TabIndex = 57;
            this.groupBox8.TabStop = false;
            // 
            // arrow8
            // 
            this.arrow8.Image = ((System.Drawing.Image)(resources.GetObject("arrow8.Image")));
            this.arrow8.Location = new System.Drawing.Point(66, 64);
            this.arrow8.Name = "arrow8";
            this.arrow8.Size = new System.Drawing.Size(40, 40);
            this.arrow8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.arrow8.TabIndex = 12;
            this.arrow8.TabStop = false;
            this.arrow8.Visible = false;
            // 
            // lb81
            // 
            this.lb81.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lb81.Location = new System.Drawing.Point(15, 18);
            this.lb81.Name = "lb81";
            this.lb81.Size = new System.Drawing.Size(140, 20);
            this.lb81.TabIndex = 8;
            this.lb81.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb84
            // 
            this.lb84.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb84.Location = new System.Drawing.Point(15, 136);
            this.lb84.Name = "lb84";
            this.lb84.Size = new System.Drawing.Size(140, 20);
            this.lb84.TabIndex = 11;
            this.lb84.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb82
            // 
            this.lb82.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb82.Location = new System.Drawing.Point(15, 35);
            this.lb82.Name = "lb82";
            this.lb82.Size = new System.Drawing.Size(140, 20);
            this.lb82.TabIndex = 9;
            this.lb82.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb83
            // 
            this.lb83.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lb83.Location = new System.Drawing.Point(2, 116);
            this.lb83.Name = "lb83";
            this.lb83.Size = new System.Drawing.Size(166, 20);
            this.lb83.TabIndex = 10;
            this.lb83.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // EnergyConvertButton
            // 
            this.EnergyConvertButton.Location = new System.Drawing.Point(175, 19);
            this.EnergyConvertButton.Name = "EnergyConvertButton";
            this.EnergyConvertButton.Size = new System.Drawing.Size(160, 20);
            this.EnergyConvertButton.TabIndex = 16;
            this.EnergyConvertButton.Text = "Convert";
            this.EnergyConvertButton.UseVisualStyleBackColor = true;
            this.EnergyConvertButton.Click += new System.EventHandler(this.EnergyConvertButton_Click);
            // 
            // fromTextEnergy
            // 
            this.fromTextEnergy.Location = new System.Drawing.Point(9, 19);
            this.fromTextEnergy.Name = "fromTextEnergy";
            this.fromTextEnergy.Size = new System.Drawing.Size(160, 20);
            this.fromTextEnergy.TabIndex = 15;
            this.fromTextEnergy.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fromTextEnergy_KeyDown);
            this.fromTextEnergy.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.fromTextEnergy_KeyPress);
            // 
            // toTextEnergy
            // 
            this.toTextEnergy.Location = new System.Drawing.Point(341, 19);
            this.toTextEnergy.Name = "toTextEnergy";
            this.toTextEnergy.ReadOnly = true;
            this.toTextEnergy.Size = new System.Drawing.Size(170, 20);
            this.toTextEnergy.TabIndex = 54;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 3);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(33, 13);
            this.label15.TabIndex = 51;
            this.label15.Text = "From:";
            // 
            // toBoxEnergy
            // 
            this.toBoxEnergy.FormattingEnabled = true;
            this.toBoxEnergy.Items.AddRange(new object[] {
            "Joule                                       [J]",
            "Kilojoule\t                              [kJ]",
            "Kilowatt-hour                    [kW*h]",
            "Watt-hour                           [W*h]",
            "Horsepower-hour               [hp*h]",
            "Gigajoule                              [GJ]",
            "Megajoule                            [MJ]",
            "Gigawatt-hour\t        [GW*h]",
            "Megawatt-hour                [MW*h]",
            "Kilowatt-second                [kW*s]",
            "Watt-second                      [W*s]",
            "Newton-meter                     [N*m]",
            "Kilocalorie                           [kcal]",
            "Calorie\t\t             [cal]",
            "Kilogram-force meter        [kgf*m]",
            "Pound-force foot                [lbf*ft]",
            "Pound-force inch               [lbf*in]"});
            this.toBoxEnergy.Location = new System.Drawing.Point(175, 45);
            this.toBoxEnergy.Name = "toBoxEnergy";
            this.toBoxEnergy.Size = new System.Drawing.Size(160, 238);
            this.toBoxEnergy.TabIndex = 56;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(341, 3);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(40, 13);
            this.label16.TabIndex = 52;
            this.label16.Text = "Result:";
            // 
            // fromBoxEnergy
            // 
            this.fromBoxEnergy.FormattingEnabled = true;
            this.fromBoxEnergy.Items.AddRange(new object[] {
            "Joule                                       [J]",
            "Kilojoule\t                              [kJ]",
            "Kilowatt-hour                    [kW*h]",
            "Watt-hour                           [W*h]",
            "Horsepower-hour               [hp*h]",
            "Gigajoule                              [GJ]",
            "Megajoule                            [MJ]",
            "Gigawatt-hour\t        [GW*h]",
            "Megawatt-hour                [MW*h]",
            "Kilowatt-second                [kW*s]",
            "Watt-second                      [W*s]",
            "Newton-meter                     [N*m]",
            "Kilocalorie                           [kcal]",
            "Calorie\t\t             [cal]",
            "Kilogram-force meter        [kgf*m]",
            "Pound-force foot                [lbf*ft]",
            "Pound-force inch               [lbf*in]"});
            this.fromBoxEnergy.Location = new System.Drawing.Point(9, 45);
            this.fromBoxEnergy.Name = "fromBoxEnergy";
            this.fromBoxEnergy.Size = new System.Drawing.Size(160, 238);
            this.fromBoxEnergy.TabIndex = 55;
            // 
            // tabPage8
            // 
            this.tabPage8.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage8.Controls.Add(this.groupBox9);
            this.tabPage8.Controls.Add(this.SpeedConvertButton);
            this.tabPage8.Controls.Add(this.fromTextSpeed);
            this.tabPage8.Controls.Add(this.toTextSpeed);
            this.tabPage8.Controls.Add(this.from);
            this.tabPage8.Controls.Add(this.toBoxSpeed);
            this.tabPage8.Controls.Add(this.label18);
            this.tabPage8.Controls.Add(this.fromBoxSpeed);
            this.tabPage8.Location = new System.Drawing.Point(104, 4);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(584, 400);
            this.tabPage8.TabIndex = 8;
            this.tabPage8.Text = "Speed";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.arrow9);
            this.groupBox9.Controls.Add(this.lb91);
            this.groupBox9.Controls.Add(this.lb94);
            this.groupBox9.Controls.Add(this.lb92);
            this.groupBox9.Controls.Add(this.lb93);
            this.groupBox9.Location = new System.Drawing.Point(341, 39);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(170, 170);
            this.groupBox9.TabIndex = 64;
            this.groupBox9.TabStop = false;
            // 
            // arrow9
            // 
            this.arrow9.Image = ((System.Drawing.Image)(resources.GetObject("arrow9.Image")));
            this.arrow9.Location = new System.Drawing.Point(66, 64);
            this.arrow9.Name = "arrow9";
            this.arrow9.Size = new System.Drawing.Size(40, 40);
            this.arrow9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.arrow9.TabIndex = 12;
            this.arrow9.TabStop = false;
            this.arrow9.Visible = false;
            // 
            // lb91
            // 
            this.lb91.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lb91.Location = new System.Drawing.Point(15, 18);
            this.lb91.Name = "lb91";
            this.lb91.Size = new System.Drawing.Size(140, 20);
            this.lb91.TabIndex = 8;
            this.lb91.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb94
            // 
            this.lb94.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb94.Location = new System.Drawing.Point(15, 136);
            this.lb94.Name = "lb94";
            this.lb94.Size = new System.Drawing.Size(140, 20);
            this.lb94.TabIndex = 11;
            this.lb94.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb92
            // 
            this.lb92.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb92.Location = new System.Drawing.Point(15, 35);
            this.lb92.Name = "lb92";
            this.lb92.Size = new System.Drawing.Size(140, 20);
            this.lb92.TabIndex = 9;
            this.lb92.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb93
            // 
            this.lb93.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lb93.Location = new System.Drawing.Point(2, 116);
            this.lb93.Name = "lb93";
            this.lb93.Size = new System.Drawing.Size(166, 20);
            this.lb93.TabIndex = 10;
            this.lb93.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SpeedConvertButton
            // 
            this.SpeedConvertButton.Location = new System.Drawing.Point(175, 19);
            this.SpeedConvertButton.Name = "SpeedConvertButton";
            this.SpeedConvertButton.Size = new System.Drawing.Size(160, 20);
            this.SpeedConvertButton.TabIndex = 18;
            this.SpeedConvertButton.Text = "Convert";
            this.SpeedConvertButton.UseVisualStyleBackColor = true;
            this.SpeedConvertButton.Click += new System.EventHandler(this.SpeedConvertButton_Click);
            // 
            // fromTextSpeed
            // 
            this.fromTextSpeed.Location = new System.Drawing.Point(9, 19);
            this.fromTextSpeed.Name = "fromTextSpeed";
            this.fromTextSpeed.Size = new System.Drawing.Size(160, 20);
            this.fromTextSpeed.TabIndex = 17;
            this.fromTextSpeed.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fromTextSpeed_KeyDown);
            this.fromTextSpeed.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.fromTextSpeed_KeyPress);
            // 
            // toTextSpeed
            // 
            this.toTextSpeed.Location = new System.Drawing.Point(341, 19);
            this.toTextSpeed.Name = "toTextSpeed";
            this.toTextSpeed.ReadOnly = true;
            this.toTextSpeed.Size = new System.Drawing.Size(170, 20);
            this.toTextSpeed.TabIndex = 61;
            // 
            // from
            // 
            this.from.AutoSize = true;
            this.from.Location = new System.Drawing.Point(6, 3);
            this.from.Name = "from";
            this.from.Size = new System.Drawing.Size(33, 13);
            this.from.TabIndex = 58;
            this.from.Text = "From:";
            // 
            // toBoxSpeed
            // 
            this.toBoxSpeed.FormattingEnabled = true;
            this.toBoxSpeed.Items.AddRange(new object[] {
            "Meter/second                     [m/s]",
            "Kilometer/hour                  [km/h]",
            "Mile/hour                           [mi/h]",
            "Knot                                  [kt,kn]",
            "Mach"});
            this.toBoxSpeed.Location = new System.Drawing.Point(175, 45);
            this.toBoxSpeed.Name = "toBoxSpeed";
            this.toBoxSpeed.Size = new System.Drawing.Size(160, 238);
            this.toBoxSpeed.TabIndex = 63;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(341, 3);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(40, 13);
            this.label18.TabIndex = 59;
            this.label18.Text = "Result:";
            // 
            // fromBoxSpeed
            // 
            this.fromBoxSpeed.FormattingEnabled = true;
            this.fromBoxSpeed.Items.AddRange(new object[] {
            "Meter/second                     [m/s]",
            "Kilometer/hour                  [km/h]",
            "Mile/hour                           [mi/h]",
            "Knot                                  [kt,kn]",
            "Mach"});
            this.fromBoxSpeed.Location = new System.Drawing.Point(8, 45);
            this.fromBoxSpeed.Name = "fromBoxSpeed";
            this.fromBoxSpeed.Size = new System.Drawing.Size(160, 238);
            this.fromBoxSpeed.TabIndex = 62;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(670, 398);
            this.Controls.Add(this.Units);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "Unit Converter";
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.arrow1)).EndInit();
            this.Units.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.arrow2)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.arrow3)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.arrow4)).EndInit();
            this.Volume.ResumeLayout(false);
            this.Volume.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.arrow5)).EndInit();
            this.Length.ResumeLayout(false);
            this.Length.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.arrow6)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.arrow7)).EndInit();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.arrow8)).EndInit();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.arrow9)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button LengthConvertButton;
        private System.Windows.Forms.TextBox fromText;
        private System.Windows.Forms.TextBox toText;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox toBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox fromBox;
        private System.Windows.Forms.TabControl Units;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button WeightConverButton;
        private System.Windows.Forms.TextBox fromTextWeight;
        private System.Windows.Forms.TextBox toTextWeight;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox toBoxWeight;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox fromBoxWeight;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button TempConverButton;
        private System.Windows.Forms.TextBox fromTextTemp;
        private System.Windows.Forms.TextBox toTextTemp;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox toBoxTemp;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox fromBoxTemp;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button AngleConvertButton;
        private System.Windows.Forms.TextBox fromTextAngle;
        private System.Windows.Forms.TextBox toTextAngle;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ListBox toBoxAngle;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ListBox fromBoxAngle;
        private System.Windows.Forms.TabPage Volume;
        private System.Windows.Forms.Button VolumeConvertButton;
        private System.Windows.Forms.TextBox fromTextVol;
        private System.Windows.Forms.TextBox toTextVol;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ListBox toBoxVol;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ListBox fromBoxVol;
        private System.Windows.Forms.TabPage Length;
        private System.Windows.Forms.Button PressureConvertButton;
        private System.Windows.Forms.TextBox fromTextPressure;
        private System.Windows.Forms.TextBox toTextPressure;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ListBox toBoxPressure;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ListBox fromBoxPressure;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button ForceConvertButton;
        private System.Windows.Forms.TextBox fromTextForce;
        private System.Windows.Forms.TextBox toTextForce;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ListBox toBoxForce;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ListBox fromBoxForce;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Button EnergyConvertButton;
        private System.Windows.Forms.TextBox fromTextEnergy;
        private System.Windows.Forms.TextBox toTextEnergy;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ListBox toBoxEnergy;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ListBox fromBoxEnergy;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.Button SpeedConvertButton;
        private System.Windows.Forms.TextBox fromTextSpeed;
        private System.Windows.Forms.TextBox toTextSpeed;
        private System.Windows.Forms.Label from;
        private System.Windows.Forms.ListBox toBoxSpeed;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ListBox fromBoxSpeed;
        private System.Windows.Forms.Label lbLen1;
        private System.Windows.Forms.Label unitLen1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label unitLen2;
        private System.Windows.Forms.Label lbLen2;
        private System.Windows.Forms.PictureBox arrow1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.PictureBox arrow2;
        private System.Windows.Forms.Label lb21;
        private System.Windows.Forms.Label lb24;
        private System.Windows.Forms.Label lb22;
        private System.Windows.Forms.Label lb23;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.PictureBox arrow3;
        private System.Windows.Forms.Label lb31;
        private System.Windows.Forms.Label lb34;
        private System.Windows.Forms.Label lb32;
        private System.Windows.Forms.Label lb33;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.PictureBox arrow4;
        private System.Windows.Forms.Label lb41;
        private System.Windows.Forms.Label lb44;
        private System.Windows.Forms.Label lb42;
        private System.Windows.Forms.Label lb43;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.PictureBox arrow5;
        private System.Windows.Forms.Label lb51;
        private System.Windows.Forms.Label lb54;
        private System.Windows.Forms.Label lb52;
        private System.Windows.Forms.Label lb53;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.PictureBox arrow6;
        private System.Windows.Forms.Label lb61;
        private System.Windows.Forms.Label lb64;
        private System.Windows.Forms.Label lb62;
        private System.Windows.Forms.Label lb63;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.PictureBox arrow7;
        private System.Windows.Forms.Label lb71;
        private System.Windows.Forms.Label lb74;
        private System.Windows.Forms.Label lb72;
        private System.Windows.Forms.Label lb73;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.PictureBox arrow8;
        private System.Windows.Forms.Label lb81;
        private System.Windows.Forms.Label lb84;
        private System.Windows.Forms.Label lb82;
        private System.Windows.Forms.Label lb83;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.PictureBox arrow9;
        private System.Windows.Forms.Label lb91;
        private System.Windows.Forms.Label lb94;
        private System.Windows.Forms.Label lb92;
        private System.Windows.Forms.Label lb93;
    }
}

